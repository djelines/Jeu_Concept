﻿dico={}
dico['parapluie']=[0,34,56]
dico['musee']=[16, 54, 11]
dico['cheval']=[6, 33, 27, 96, 112]
dico['lion']=[6, 33, 45, 39]
dico['Pere Noel']=[3, 19, 98, 105]
dico['escargot']=[6, 32, 27, 82]Texte � �crire dans le fichierTexte � �crire dans le fichier